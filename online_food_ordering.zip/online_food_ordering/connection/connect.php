<?php

$servername = "sql210.infinityfree.com"; //server
$username = "if0_37794948"; //username
$password = "4xjiqa9ju5VN8J"; //password
$dbname = "if0_37794948_online_ordering";  //database

// Create connection
$db = mysqli_connect($servername, $username, $password, $dbname); // connecting 
// Check connection
if (!$db) {       //checking connection to DB	
    die("Connection failed: " . mysqli_connect_error());
}
?>