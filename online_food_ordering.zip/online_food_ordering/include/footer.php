      <footer class="footer">
          <div class="container">


              <div class="bottom-footer">
                  <div class="row">
                      <div class="col-xs-12 col-sm-4 address color-gray">
                          <h5>Address</h5>
                          <p>Philippines, Manila, Char CHar</p>
                          <h5>Phone: +63123456789</a></h5>
                      </div>
                      <div class="col-xs-12 col-sm-5 additional-info color-gray">
                          <h5>Addition informations</h5>
                          <p>You can enjoy ordering cupcakes/cakes in here!</p>
                      </div>
                  </div>
              </div>

          </div>
      </footer>