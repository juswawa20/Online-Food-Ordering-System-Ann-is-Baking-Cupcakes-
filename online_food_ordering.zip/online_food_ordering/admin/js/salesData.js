// Initialize the chart
var ctx = document.getElementById('earningsChart').getContext('2d');
var earningsChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [], // Initially empty, will be filled with data
        datasets: [{
            label: 'Total Earnings',
            data: [], // Initially empty, will be filled with data
            borderColor: 'rgba(75, 192, 192, 1)',
            fill: false
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true // Ensure the y-axis starts from zero
            }
        }
    }
});

// Function to update the chart with new data
function updateChart(labels, data) {
    // Reset data if labels are empty
    if (labels.length === 0 || data.length === 0) {
        earningsChart.data.labels = ['No data available']; // Optional message when no data
        earningsChart.data.datasets[0].data = [0]; // Display 0 if no data
    } else {
        earningsChart.data.labels = labels;
        earningsChart.data.datasets[0].data = data;
    }
    earningsChart.update();
}

// AJAX function to get sales data (Daily, Monthly, Yearly)
function fetchSalesData(period) {
    $.ajax({
        url: "getSalesData.php", // Use a separate PHP file to handle sales data requests
        type: "GET",
        data: { period: period },
        success: function(response) {
            var result = JSON.parse(response);
            // If there's no data, reset to show a zero value
            if (!result.labels || !result.data || result.data.length === 0) {
                result.labels = ['No data'];
                result.data = [0];
            }
            updateChart(result.labels, result.data);
        }
    });
}

// Button click events to trigger different sales periods
$('#dailyBtn').click(function() {
    fetchSalesData('daily');
});

$('#monthlyBtn').click(function() {
    fetchSalesData('monthly');
});

$('#yearlyBtn').click(function() {
    fetchSalesData('yearly');
});
