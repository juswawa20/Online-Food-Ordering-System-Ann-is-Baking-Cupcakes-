<?php
include("../connection/connect.php");

if(isset($_GET['period'])) {
    $period = $_GET['period'];
    $sql = '';

    if($period == 'daily') {
        $sql = "SELECT DATE(date) AS date, SUM(price) AS total_sales FROM users_orders WHERE status = 'closed' GROUP BY DATE(date)";
    } elseif($period == 'monthly') {
        $sql = "SELECT MONTH(date) AS month, YEAR(date) AS year, SUM(price) AS total_sales FROM users_orders WHERE status = 'closed' GROUP BY YEAR(date), MONTH(date)";
    } elseif($period == 'yearly') {
        $sql = "SELECT YEAR(date) AS year, SUM(price) AS total_sales FROM users_orders WHERE status = 'closed' GROUP BY YEAR(date)";
    }

    $result = mysqli_query($db, $sql);
    $labels = [];
    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
        if($period == 'daily') {
            // Convert date to "Month Day, Year" format (e.g., January 1, 2024)
            $formattedDate = date("F j, Y", strtotime($row['date']));
            $labels[] = $formattedDate; // Use the formatted date
        } elseif($period == 'monthly') {
            // Convert numeric month to month name
            $monthNumber = (int) $row['month'];
            $monthName = date("F", mktime(0, 0, 0, $monthNumber, 10)); // Get month name from number
            $labels[] = $monthName . ' ' . $row['year']; // Format like "January 2024"
        } elseif($period == 'yearly') {
            $labels[] = $row['year'];
        }
        $data[] = (int) $row['total_sales'];
    }

    echo json_encode(['labels' => $labels, 'data' => $data]);
}
?>
