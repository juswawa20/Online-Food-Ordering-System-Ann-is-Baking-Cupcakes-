accounts:

    user1
    user123


    admin
    admin123


locally run through xampp