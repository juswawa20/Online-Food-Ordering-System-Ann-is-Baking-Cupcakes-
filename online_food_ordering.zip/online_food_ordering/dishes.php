<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php"); 
error_reporting(0);
session_start();

include_once 'product-action.php'; 
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dishes || Online Food Ordering System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> 
                    <img class="img-rounded" src="images/logo.png" alt="" width="5%"> 
                </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                        <?php
                        if (empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a></li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a></li>';
                        } else {
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a></li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="page-wrapper">
        <div class="breadcrumb">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item active"><span>1</span><a href="dishes.php">Pick Your Favorite Food</a></li>
                    <li class="col-xs-12 col-sm-4 link-item"><span>2</span><a href="#">Order and Pay</a></li>
                </ul>
            </div>
        </div>

        <div class="container m-t-30">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-3">
                    <div class="widget widget-cart">
                        <div class="widget-heading">
                            <h3 class="widget-title text-dark">Your Cart</h3>
                            <div class="clearfix"></div>
                        </div>
                        <div class="order-row bg-white">
                            <div class="widget-body">
                                <?php
                                $item_total = 0;
                                if (!empty($_SESSION["cart_item"])) {
                                    foreach ($_SESSION["cart_item"] as $item) {
                                        echo "<div class='title-row'>
                                                {$item['title']}
                                                <a href='dishes.php?action=remove&id={$item['d_id']}'>
                                                    <i class='fa fa-trash pull-right'></i>
                                                </a>
                                              </div>";
                                        echo "<div class='form-group row no-gutter'>
                                                <div class='col-xs-8'>
                                                    <input type='text' class='form-control b-r-0' value='{$item['price']}' readonly>
                                                </div>
                                                <div class='col-xs-4'>
                                                    <input class='form-control' type='text' readonly value='{$item['quantity']}'>
                                                </div>
                                              </div>";
                                        $item_total += ($item["price"] * $item["quantity"]);
                                    }
                                }
                                ?>
                            </div>
                        </div>
                        <div class="widget-body">
                            <div class="price-wrap text-xs-center">
                                <p>TOTAL</p>
                                <h3 class="value"><strong><?php echo "Php " . $item_total; ?></strong></h3>
                                <p>Free Delivery!</p>
                                <?php
                                if ($item_total == 0) {
                                    echo '<a href="checkout.php?action=check" class="btn btn-danger btn-lg disabled">Checkout</a>';
                                } else {
                                    echo '<a href="checkout.php?action=check" class="btn btn-success btn-lg active">Checkout</a>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="menu-widget">
                        <div class="widget-heading">
                            <h3 class="widget-title text-dark">MENU</h3>
                            <div class="clearfix"></div>
                        </div>
                        <div>
                            <?php
                            $stmt = $db->prepare("SELECT * FROM dishes");
                            $stmt->execute();
                            $products = $stmt->get_result();
                            if (!empty($products)) {
                                foreach ($products as $product) {
                                    echo "<div class='food-item'>
                                            <div class='row'>
                                                <div class='rest-logo pull-left'>
                                                    <a class='restaurant-logo pull-left' href='#'>
                                                        <img src='admin/Res_img/dishes/{$product['img']}' alt='Food logo' style='width: 80px; height: 80px; object-fit: cover;'>
                                                    </a>
                                                </div>
                                                <div class='col-xs-12 col-sm-12 col-lg-8'>
                                                    <div class='rest-descr'>
                                                        <h6><a href='#'>{$product['title']}</a></h6>
                                                        <p>{$product['slogan']}</p>
                                                    </div>
                                                </div>
                                                <div class='col-xs-12 col-sm-12 col-lg-3 pull-right item-cart-info'>";

                                    if ($product['quantity'] > 0) {
                                        echo "
                                        <p><strong>Available Stock:</strong> {$product['quantity']}</p>

                                        <span class='price pull-left'>Php {$product['price']}</span>
                                              <form method='post' action='dishes.php?action=add&id={$product['d_id']}'>
                                                  <input type='number' name='quantity' value='1' min='1' max='{$product['quantity']}' class='form-control' style='width: 60px; display: inline-block;' required>
                                                  <input type='submit' class='btn theme-btn' value='Add To Cart'>
                                              </form>";
                                    } else {
                                        echo "
                                        <p><strong>Available Stock:</strong> {$product['quantity']}</p>
                                        <span class='price pull-left'>Php {$product['price']}</span>
                                              <button class='btn btn-danger' disabled>Out of Stock</button>";
                                    }

                                    echo "      </div>
                                            </div>
                                          </div>";
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include "include/footer.php" ?>
    </div>
</body>
</html>
